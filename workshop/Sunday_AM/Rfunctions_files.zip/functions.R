# write a function to convert temperatures from Fahrenheits to Celcius

rm(list=ls())

# this function converts temp ..
convertFahrToCelc <- function(tempFahr) {
  # body of the function goes here
  tempCel <- (tempFahr - 32) * (5/9)
  return(tempCel)
}

waterBpF = 212
print(convertFahrToCelc(waterBpF))
print(convertFahrToCelc(500))
print(convertFahrToCelc(2000))
