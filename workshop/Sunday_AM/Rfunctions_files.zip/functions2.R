# Compute the avg GDP per capita for a given country

# clear the workspace
rm(list=ls())

# read in the data file
fileName <- 'data/gapminderData.csv'
gapminder <- read.csv(fileName)

# specify country name here
countryName <- 'United States'

computeAvgGdp <- function(countryName, startYear = 1950, endYear = 2010) {
  # extract the relevant info and find the average
  data <- gapminder[gapminder$country == countryName &
                      gapminder$year >= startYear & 
                      gapminder$year <= endYear, ]
  gdp <- data[, 'gdpPercap']
  avgGdp <- mean(gdp)
  
  return(avgGdp)
}

startYear <- 1950
endYear <- 1960

avgGdp <- computeAvgGdp(countryName, startYear, endYear)

# print our results
print(paste('The average GDP per cap from', startYear, 'to', endYear, 'of', countryName, 'is', avgGdp))

startYear <- 2000
endYear <- 2010

avgGdp <- computeAvgGdp(countryName, startYear, endYear)

# print our results
print(paste('The average GDP per cap from', startYear, 'to', endYear, 'of', countryName, 'is', avgGdp))
