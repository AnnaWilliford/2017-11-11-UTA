data('iris')

head(iris)

result <- vector()
for(i in 1:nrow(iris)) {
  result[i] <- iris$Sepal.Width[i] / iris$Sepal.Length[i]
}

print(result)
plot(result)
head(iris)
abline(v=50)
abline(v=100)
