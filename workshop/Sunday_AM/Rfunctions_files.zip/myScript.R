# Compute the avg GDP per capita for a given country

# clear the workspace
rm(list=ls())

# read in the data file
fileName <- 'data/gapminderData.csv'
gapminder <- read.csv(fileName)

# specify country name here
countryName <- 'United States'

# extract the relevant info and find the average
data <- gapminder[gapminder$country==countryName , ]
gdp <- data[, 'gdpPercap']
avgGdp <- mean(gdp)

# print our results
print(paste('The average GDP per cap of', countryName, 'is', avgGdp))
